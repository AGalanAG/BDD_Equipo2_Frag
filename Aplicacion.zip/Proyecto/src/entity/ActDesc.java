/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Alan
 */
public class ActDesc {
    private int id;
    private float desct;
    private String fecha;

    public ActDesc() {
    }

    public ActDesc(int id, float desct, String fecha) {
        this.id = id;
        this.desct = desct;
        this.fecha = fecha;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getDesct() {
        return desct;
    }

    public void setDesct(float desct) {
        this.desct = desct;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
    
    
}
