/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Alan
 */
public class ventas2 {
    private int ProductID;
    private String Nombre;
    private int Veces_Vendido;

    public ventas2() {
    }

    public ventas2(int ProductID, String Nombre, int Veces_Vendido) {
        this.ProductID = ProductID;
        this.Nombre = Nombre;
        this.Veces_Vendido = Veces_Vendido;
    }

    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getVeces_Vendido() {
        return Veces_Vendido;
    }

    public void setVeces_Vendido(int Veces_Vendido) {
        this.Veces_Vendido = Veces_Vendido;
    }
    
    
}
