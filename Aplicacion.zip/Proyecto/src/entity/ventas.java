/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Alan
 */
public class ventas {
    
    private int ProductID;
    private String Nombre;
    private float Precio;
    private int cantidad;


    public ventas() {
    }

    public ventas(int ProductID, String Nombre, float Precio, int cantidad) {
        this.ProductID = ProductID;
        this.Nombre = Nombre;
        this.Precio = Precio;
        this.cantidad = cantidad;

    }


    public int getProductID() {
        return ProductID;
    }

    public void setProductID(int ProductID) {
        this.ProductID = ProductID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public float getPrecio() {
        return Precio;
    }

    public void setPrecio(int Precio) {
        this.Precio = Precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
}
