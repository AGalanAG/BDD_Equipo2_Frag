/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Alan
 */
public class Ordenes {
        private int ID;
    private int Terr;
    private String Nombre;
    private String fech;

    public Ordenes() {
    }

    public Ordenes(int ID, int Terr, String Nombre, String fech) {
        this.ID = ID;
        this.Terr = Terr;
        this.Nombre = Nombre;
        this.fech = fech;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getTerr() {
        return Terr;
    }

    public void setTerr(int Terr) {
        this.Terr = Terr;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getFech() {
        return fech;
    }

    public void setFech(String fech) {
        this.fech = fech;
    }
    
    
}
