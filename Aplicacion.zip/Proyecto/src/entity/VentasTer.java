/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Alan
 */
public class VentasTer {
    
        private String Nombre;
        private float Total;

    public VentasTer() {
    }

    public VentasTer(String Nombre, float Total) {
        this.Nombre = Nombre;
        this.Total = Total;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public float getTotal() {
        return Total;
    }

    public void setTotal(float Total) {
        this.Total = Total;
    }
        
    
}
