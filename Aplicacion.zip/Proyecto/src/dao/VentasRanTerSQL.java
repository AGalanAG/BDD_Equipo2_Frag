/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import db.DBConection;
import entity.VentasRanTer;
import entity.ventas;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alan
 */
public class VentasRanTerSQL implements VentasRanTerDAO{
    
    DBConection dbcon;

public VentasRanTerSQL() {
    dbcon = new DBConection();
        dbcon.setUrl("jdbc:sqlserver://LAPTOP-L1AI9EU8\\MSSQLSERVER2;databaseName=AdventureSales;integratedSecurity=true");
        

}
    


    public List<VentasRanTer> getVentasRanTer(int tipo) {
        List<VentasRanTer> lista = new ArrayList<>();
        Connection conn = dbcon.Conexion();
              try {
         Statement st = conn.createStatement();
         String rq  = "exec consulta_d1 "+tipo;
          st.executeUpdate(rq);
         ResultSet rs = st.getGeneratedKeys(); 
         
         while (rs.next()){
         lista.add(new VentasRanTer(rs.getString(1),Integer.parseInt(rs.getString(2))));
         }
         dbcon.Desconectar();
         
      } catch (SQLException ex) {
          throw new RuntimeException("Error", ex);
      }
        
        
        
        
        return lista;   
    }
    
    
}
