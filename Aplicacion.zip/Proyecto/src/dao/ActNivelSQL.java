/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import db.DBConection;
import entity.ActNivel;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alan
 */
public class ActNivelSQL implements ActNivelDAO {
    
        DBConection dbcon;

    public ActNivelSQL() {
        dbcon = new DBConection();
        dbcon.setUrl("jdbc:sqlserver://LAPTOP-L1AI9EU8\\MSSQLSERVER;databaseName=Adventure;integratedSecurity=true");
        
    }
    

    @Override
    public List<ActNivel> getActNivel(int id,int Niv,String color) {
                List<ActNivel> lista = new ArrayList<>();
        Connection conn = dbcon.Conexion();
              try {
         Statement st = conn.createStatement();
         String rq  = "exec Actualizar_Nivel "+id+","+Niv+","+color+" ";
                st.executeUpdate(rq);
         ResultSet rs = st.getGeneratedKeys();
         //int Id, String Nombre, String color, int Nivel, String Fecha
         while (rs.next()){
         lista.add(new ActNivel(Integer.parseInt(rs.getString(1)),rs.getString(2),rs.getString(3),Integer.parseInt(rs.getString(4)),rs.getString(5)));
         }
         dbcon.Desconectar();
         
      } catch (SQLException ex) {
          throw new RuntimeException("Error", ex);
      }
        
        
        
        
        return lista;}
    
}
