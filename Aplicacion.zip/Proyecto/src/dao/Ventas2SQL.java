/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;
import db.DBConection;
import entity.ventas2;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alan
 */
public class Ventas2SQL implements Ventas2DAO{
        DBConection dbcon;

    public Ventas2SQL() {
     dbcon = new DBConection();
        dbcon.setUrl("jdbc:sqlserver://LAPTOP-L1AI9EU8\\MSSQLSERVER2;databaseName=AdventureSales;integratedSecurity=true");
        
    }
    
    public List<ventas2> getVentas2() {
        List<ventas2> lista = new ArrayList<>();
        Connection conn = dbcon.Conexion();
              try {
         Statement st = conn.createStatement();
         String rq  = "exec Productos_Vendidos";
         ResultSet rs = st.executeQuery(rq);
         
         while (rs.next()){
         lista.add(new ventas2(Integer.parseInt(rs.getString(1)), rs.getString(2),Integer.parseInt(rs.getString(3))));
         }
         dbcon.Desconectar();
         
      } catch (SQLException ex) {
          throw new RuntimeException("Error", ex);
      }
        
        
        
    
        return lista;
    }

 
    public List<ventas2> getVentas3() {
  List<ventas2> lista = new ArrayList<>();
        Connection conn = dbcon.Conexion();
              try {
         Statement st = conn.createStatement();
         String rq  = "exec Productos_Vendidos2";
         ResultSet rs = st.executeQuery(rq);
         
         while (rs.next()){
         lista.add(new ventas2(Integer.parseInt(rs.getString(1)), rs.getString(2),Integer.parseInt(rs.getString(3))));
         }
         dbcon.Desconectar();
         
      } catch (SQLException ex) {
          throw new RuntimeException("Error", ex);
      }
        
        
        
        
        return lista;
    }


  
}
