/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import db.DBConection;

import entity.ventas;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alan
 */
public class VentasSQL implements VentasDAO {
    
    DBConection dbcon;

    public VentasSQL() {
        dbcon = new DBConection();
        dbcon.setUrl("jdbc:sqlserver://LAPTOP-L1AI9EU8\\MSSQLSERVER2;databaseName=AdventureSales;integratedSecurity=true");
        
    }
    
 
    public List<ventas> getVentas() {
        
        List<ventas> lista = new ArrayList<>();
        Connection conn = dbcon.Conexion();
              try {
         Statement st = conn.createStatement();
         String rq  = "exec consulta_p";
         ResultSet rs = st.executeQuery(rq);
         
         while (rs.next()){
         lista.add(new ventas(Integer.parseInt(rs.getString(1)), rs.getString(2),Float.parseFloat(rs.getString(3)),Integer.parseInt(rs.getString(4))));
         }
         dbcon.Desconectar();
         
      } catch (SQLException ex) {
          throw new RuntimeException("Error", ex);
      }
        
        
        
        
        return lista;
        }

    
}
