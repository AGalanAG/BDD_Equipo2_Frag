/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.ActNivel;
import java.util.List;

/**
 *
 * @author Alan
 */
public interface ActNivelDAO {
        public List<ActNivel> getActNivel(int id,int Niv,String color);
    
}
