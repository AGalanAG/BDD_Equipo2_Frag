
package DaoImp;

import com.mysql.jdbc.Driver;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ImpDao implements TablaDao{
    
    public static final String URL = "jdbc:sqlserver://DESKTOP-I4B3KNS\\\\MSSQLSERVER:1433;databaseName=AdventureWorks2019";
    public static final String USER = "pruebalogin";
    public static final String PASS = "123";

    public static Connection getConnection()
    {
      try {
          return DriverManager.getConnection(URL, USER, PASS);
      } catch (SQLException ex) {
          throw new RuntimeException("Error connecting to the database", ex);
      }
    }


    public static void main(String[] args) {
        Connection connection = ImpDao.getConnection();
    }
    
    @Override
     public void read(){
     Connection connection = ImpDao.getConnection();
        try {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery("select top 10 * from Sales.Store");

           while(rs.next()){
           int BusinessEntityID = rs.getInt(1);
           String Name = rs.getString(2);
           int SalesPersonID = rs.getInt(3);
           String Demographics = rs.getString(4);
           String rowguid = rs.getString(5);
           String ModifiedDate = rs.getString(6);
           System.out.println(BusinessEntityID + " " + Name + " " + SalesPersonID + " " + Demographics + " " + rowguid + " " + ModifiedDate);
     }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
     
     }
     
    @Override
    public void insert(ImpDao product) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(ImpDao product) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Integer BusinessEntityID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    }
