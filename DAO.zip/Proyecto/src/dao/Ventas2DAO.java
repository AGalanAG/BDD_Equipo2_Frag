/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.ventas2;
import java.util.List;

/**
 *
 * @author Alan
 */
public interface Ventas2DAO {
        public List<ventas2> getVentas2();
        public List<ventas2> getVentas3();

}
