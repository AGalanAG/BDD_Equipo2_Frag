/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Alan
 */
public class DBConection {
    
    private String url ="";
    //Se se usa la autenticacion de sql con un usuario creado hay que descomentar y crear los Getters y Setters de estos
    //private String user ="";
    //private String password ="";
    Connection conn = null;
    
    public DBConection(){

    }
    
    public Connection Conexion(){
    try{
        // conn=DriverManager.getConnection(url,user,password);
        conn=DriverManager.getConnection(url); //Si se usa autenticacion de sql hay que cambiar a la linea anterior 
    
    }catch(SQLException ex){
        throw new RuntimeException("Error connecting to the database", ex);
    }
    return conn;
    }
    
    public void Desconectar(){
    try{
    conn.close();
    }catch(SQLException ex){
     throw new RuntimeException("Error desconectando la base de datos", ex);}
    
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    
    
    
    
}
