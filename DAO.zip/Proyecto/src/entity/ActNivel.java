/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Alan
 */
public class ActNivel {
    private int Id;
    private String Nombre;
    private String color;
    private int Nivel;
    private String Fecha;

    public ActNivel() {
    }

    public ActNivel(int Id, String Nombre, String color, int Nivel, String Fecha) {
        this.Id = Id;
        this.Nombre = Nombre;
        this.color = color;
        this.Nivel = Nivel;
        this.Fecha = Fecha;
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getNivel() {
        return Nivel;
    }

    public void setNivel(int Nivel) {
        this.Nivel = Nivel;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String Fecha) {
        this.Fecha = Fecha;
    }
    
    


    
    
    
    
}
