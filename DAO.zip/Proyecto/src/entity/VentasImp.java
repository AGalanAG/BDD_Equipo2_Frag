/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Alan
 */
public class VentasImp {
    private int ID;
    private int Terr;
    private String Nombre;
    private float cant;

    public VentasImp() {
    }

    public VentasImp(int ID, int Terr, String Nombre, float cant) {
        this.ID = ID;
        this.Terr = Terr;
        this.Nombre = Nombre;
        this.cant = cant;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getTerr() {
        return Terr;
    }

    public void setTerr(int Terr) {
        this.Terr = Terr;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public float getCant() {
        return cant;
    }

    public void setCant(float cant) {
        this.cant = cant;
    }
    
    
}
